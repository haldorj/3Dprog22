#ifndef COMMONVALUES_H
#define COMMONVALUES_H

#include "stb_image.h"

const int MAX_POINT_LIGHTS = 3;

#endif // COMMONVALUES_H
