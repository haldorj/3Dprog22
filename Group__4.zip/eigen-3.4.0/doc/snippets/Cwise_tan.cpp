Array3d v(M_PI, M_PI/2, M_PI/3);
cout << v.tan() << endl;
